package process.finalver.dica;

import android.app.Activity;
import android.os.Bundle;

public class ShortpathActivity extends Activity {
	public  void  onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.shortpathview);  
    } 
}
